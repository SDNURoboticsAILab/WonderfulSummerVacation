%this is to plot all DOF's trajectories
%INPUTS: TT:time stamp      QQ:points       G:goal matrix
%Outputs: TS: time stamp when the exchange between parabolic and linear happens
function TS = DOFpointPlot(TT,QQ,G)

Q = G(:,2:end-1);
T = G(:,1);
P = G(:,end);
PT = size(G,1);

%TS: create time stamps where the exchange between parabolic and linear
%happens
TS = zeros(1,PT*2);
TS(1) = T(1);
TS(2) = T(1) + P(1);
TS(end-1) = T(end) - P(end);
TS(end) = T(end);
for i = 2:PT-1
    TS(i*2-1) = T(i)-P(i)/2;
    TS(i*2) = T(i)+P(i)/2;
end
Tint = (size(TT,1)-1)/T(end);
TS = TS.*Tint+1;

figure(1);
set(1, 'Position', [ 60 200 560 420 ]);
DOF = size(QQ,2)-1;  %the number of plots, i.e. DOF
%plot setting
LW = 4;         %linewidth
OW = 2;         %red dot size
MS = 5;         %red dot marker size
FT = 25;        %fontsize

%number of DOFs PRNo: Plot Row No; PCNo: Plot Col No.
if DOF <= 3
    PRNo = 1;
    PCNo = DOF;
else
    PRNo = 2;
    PCNo = 3;
end

for i = 1:DOF
    subplot(PRNo,PCNo,i);
    
    color = 0;
    for j = 1:length(TS)-1    
        if color == 0
            plot(TT(TS(j):TS(j+1)),QQ(TS(j):TS(j+1),i),'g','LineWidth',LW);hold on;
        else
            plot(TT(TS(j):TS(j+1)),QQ(TS(j):TS(j+1),i),'b','LineWidth',LW);hold on;
        end
        color = 1-color;
    end
    %ylim([-100 100]);
    xlim([0 T(end)]);
%     if i>=3
%         ylim([-180 180]);
%     end
    
    xlabel('T(t)');ylabel('X(t)');grid on;grid minor;
    plot(T,Q(:,i),'ro','LineWidth',OW);set(gca,'fontsize',FT);      %Plot the Red dot
end
clear color;
hold off;
%plot(TT(find(QQ(:,4))),QQ(find(QQ(:,4)),1),'g.','LineWidth',LW);
