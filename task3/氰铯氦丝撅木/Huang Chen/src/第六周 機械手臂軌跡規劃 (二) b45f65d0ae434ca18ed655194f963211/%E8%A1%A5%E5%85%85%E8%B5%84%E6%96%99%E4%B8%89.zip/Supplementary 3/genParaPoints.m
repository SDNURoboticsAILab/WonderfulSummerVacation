%this is to generate all points in trajectory planning using parabolic
%blends
function [TT, QQ] = genParaPoints(G,Tint)

%OUTPUT: TT: the time of each point, QQ: the DOFs values of each point
%INPUTS Goal Matrix, time interval

% Example
% Q = [ 21.78   -52.19    2.49    -19.95    -42.06    15.09;
%         21.78   -59.15    1       -23.98    -34.22    20.2;
%         58.66   -64.42    -12.02  25.31    -87.14    -56.23;
%         64.35   -49.49    -35.4   27.07    -82.04    -65.05;];

T = G(:,1);
Q = G(:,2:end-1);
P = G(:,end);
PT = size(Q,1);
DOF = size(Q,2);   
TT = linspace( T(1),T(end),(T(end)-T(1))/Tint+1)';    
N = length(TT);
%end of INPUTS INTERPRETATION

% �H�T�O�b�쥻�w�]�ɶ���trajectory��q�L�w�]initial�Mfinal points
T_onlyforV = T;
T_onlyforV(1) = T_onlyforV(1) + P(1)*0.5;
T_onlyforV(end) = T_onlyforV(end) - P(end)*0.5;

%% �p��linear function���t��V�Mparabolic function���[�t��A
%total sections*DOF size
V = zeros(PT+1,DOF);            
%A = zeros(2*(PT-2)+1+2, DOF);

%obtain each linear sections' V of all DOF
for i = 1:DOF
    V(2:end-1,i) = diff(Q(:,i))./diff(T_onlyforV);   
end
A = diff(V)./P;

ZeroInM = zeros(2*(PT-2)+1+2,PT);
for i = 1:PT
    ZeroInM(i*2-1,i) = 1;
end

A = ZeroInM*A;
clear ZeroInM;

%%  this is to generate the points of parabolic blends trajetories

% 1,2,3,4 columns�̧Ǭ�X, Y, theta, �Mindex�]linear = 0; parabolic = 2�^
QQ = zeros(N,DOF+1);
%% Generate the Time Step of each switch between Parabolic and Linear
TS = zeros(1,PT*2);
TS(1) = T(1);
TS(2) = T(1) + P(1);
TS(end-1) = T(end) - P(end);
TS(end) = T(end);
for i = 2:PT-1
    TS(i*2-1) = T(i)-P(i)/2;
    TS(i*2) = T(i)+P(i)/2;
end
%%
tStep = 2;
Ind = 2;            %2:Parabolic 2: Linear; Initial:2
QQ(1,:) = [Q(1,:) 2];
velo = 0;           %initial condition of V
acc = A(1,:);       %initial condition of acc

%initial conditions: looking for TI(2), Ind = 2 (Parabolic); velocity = 0;
for i = 2:N
    QQ(i,end) = Ind;
    QQ(i,1:end-1) = QQ(i-1,1:end-1) + velo*Tint + acc*Tint^2/2;   % S(i+1) = S(i) + V(i)*T + a(i)*T^2/2;
    velo = velo + acc*Tint;                               %the velocity of that moment        
    
    if (TT(i) == TS(tStep)) && (i<N)        %the moment of switch
        acc = A(tStep,:);                   %diff acceleration for each switch
        tStep = tStep + 1;
        Ind = 2-Ind;                        %switch from parabolic or linear        
    end
end